A=[2 -1 ; -1 2]


x0 = [1 1]';
tau = 1.0e-12

for i=1:10
    f = A*x0 - 1/2*cos(x0);
    J = [2+1/2*sin(x0(1)) -1 ; -1 2 + 1/2*sin(x0(2))]
    dx = -J\f;
    fprintf('%d %12/5g\n', i, norm(dx))
    x0 = x0 + dx;
    if norm(dx)<tau
        fprintf('converged to [%20.15f %20.15f]\n', x0(1), x0(2))
        break
    end
end
    